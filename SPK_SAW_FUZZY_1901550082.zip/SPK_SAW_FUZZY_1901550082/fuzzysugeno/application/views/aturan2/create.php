<?php $this->load->view('layouts/header_admin'); ?>

<div class="d-sm-flex align-items-center justify-content-between mb-4">
	<h1 class="h3 mb-0 text-gray-800"><i class="fas fa-fw fa-users"></i> Data aturan</h1>

	<a href="<?= base_url('aturan2'); ?>" class="btn btn-secondary btn-icon-split"><span class="icon text-white-50"><i class="fas fa-arrow-left"></i></span>
		<span class="text">Kembali</span>
	</a>
</div>

<?= $this->session->flashdata('message'); ?>

<div class="card shadow mb-4">
	<div class="card-header py-3">
		<h6 class="m-0 font-weight-bold text-primary"><i class="fas fa-fw fa-plus"></i> Tambah Data aturan</h6>
	</div>

	<?php echo form_open('aturan2/store'); ?>
	<div class="card-body">
		<div class="row">
			<?php foreach ($variabel as $v) {
				$himpunan = $this->aturan2_model->get_himpunan($v->id_variabel); ?>
				<input type="text" name="id_variabel[]" value="<?= $v->id_variabel ?>" hidden>
				<div class="form-group col-md-3">
					<label class="font-weight-bold"><?= $v->nama_variabel ?></label>
					<select class="form-control" name="id_himpunan_fuzzy[]" required>
						<option value="">--Pilih--</option>
						<?php foreach ($himpunan as $k) { ?>
							<option value="<?php echo $k->id_himpunan_fuzzy ?>"><?php echo $k->nama_himpunan ?></option>
						<?php } ?>
					</select>
				</div>
			<?php } ?>
			<div class="form-group col-md-3">
				<label class="font-weight-bold">THEN</label>
				<input autocomplete="off" type="number" name="output" required class="form-control" />
			</div>
		</div>
	</div>
	<div class="card-footer text-right">
		<button type="submit" class="btn btn-success"><i class="fa fa-save"></i> Simpan</button>
		<button type="reset" class="btn btn-info"><i class="fa fa-sync-alt"></i> Reset</button>
	</div>
	<?php echo form_close() ?>
</div>

<?php $this->load->view('layouts/footer_admin'); ?>