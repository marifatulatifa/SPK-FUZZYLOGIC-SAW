<?php
$this->load->view('layouts/header_admin');
?>

<div class="d-sm-flex align-items-center justify-content-between mb-4">
	<h1 class="h3 mb-0 text-gray-800"><i class="fas fa-fw fa-calculator"></i> Data Perhitungan</h1>
</div>

<?php
$matriks_x = array();
foreach ($alternatif2s as $alternatif2) :
	foreach ($variabels as $variabel) :

		$id_alternatif2 = $alternatif2->id_alternatif2;
		$id_variabel = $variabel->id_variabel;

		$n = $this->Perhitungan_model->data_nilai($id_alternatif2, $id_variabel);
		$nilai = $n['nilai'];

		$matriks_x[$id_variabel][$id_alternatif2] = $nilai;
	endforeach;
endforeach;

$nilai_da = array();
foreach ($alternatif2s as $alternatif2) :
	$id_alternatif2 = $alternatif2->id_alternatif2;
	foreach ($variabels as $variabel) :
		$id_variabel = $variabel->id_variabel;
		$x = $matriks_x[$id_variabel][$id_alternatif2];

		$himpunans = $this->Perhitungan_model->get_himpunan($id_variabel);
		foreach ($himpunans as $himpunan) {
			$id_himpunan_fuzzy = $himpunan->id_himpunan_fuzzy;
			$kurva = $himpunan->kurva;
			if ($kurva == "Linier Naik") {
				$a = $himpunan->a;
				$b = $himpunan->b;
				if ($x <= $a) {
					$da = 0;
				} elseif (($a <= $x) && ($x <= $b)) {
					$da = ($x - $a) / ($b - $a);
				} elseif ($x >= $b) {
					$da = 1;
				}
			}
			if ($kurva == "Linier Turun") {
				$a = $himpunan->a;
				$b = $himpunan->b;
				if ($x <= $a) {
					$da = 1;
				} elseif (($a <= $x) && ($x <= $b)) {
					$da = ($b - $x) / ($b - $a);
				} elseif ($x >= $b) {
					$da = 0;
				}
			}

			if ($kurva == "Segitiga") {
				$a = $himpunan->a;
				$b = $himpunan->b;
				$c = $himpunan->c;
				if (($x <= $a) || ($x >= $c)) {
					$da = 0;
				} elseif (($a <= $x) && ($x <= $b)) {
					$da = ($x - $a) / ($b - $a);
				} elseif (($b <= $x) && ($x <= $c)) {
					$da = ($c - $x) / ($c - $b);
				}
			}

			if ($kurva == "Trapesium") {
				$a = $himpunan->a;
				$b = $himpunan->b;
				$c = $himpunan->c;
				$d = $himpunan->d;
				if (($x >= $d) || ($x <= $a)) {
					$da = 0;
				} elseif (($a <= $x) && ($x <= $b)) {
					$da = ($x - $a) / ($b - $a);
				} elseif (($c <= $x) && ($x <= $d)) {
					$da = $b - ($a / $d) - $c;
				} elseif (($b <= $x) && ($x <= $c)) {
					$da = 1;
				}
			}
			$nilai_da[$id_variabel][$id_alternatif2][$id_himpunan_fuzzy] = $da;
		}
	endforeach;
endforeach;

?>

<div class="card shadow mb-4">
	<!-- /.card-header -->
	<div class="card-header py-3">
		<h6 class="m-0 font-weight-bold text-primary"><i class="fa fa-table"></i> Matriks Keputusan (X)</h6>
	</div>

	<div class="card-body">
		<div class="table-responsive">
			<table class="table table-bordered" width="100%" cellspacing="0">
				<thead class="bg-primary text-white">
					<tr align="center">
						<th width="5%" rowspan="2">No</th>
						<th>Nama alternatif</th>
						<?php foreach ($variabels as $variabel) : ?>
							<th><?= $variabel->nama_variabel ?></th>
						<?php endforeach; ?>
					</tr>
				</thead>
				<tbody>
					<?php
					$no = 1;
					foreach ($alternatif2s as $alternatif2) : ?>
						<tr align="center">
							<td><?= $no; ?></td>
							<td align="left"><?= $alternatif2->nama ?></td>
							<?php
							foreach ($variabels as $variabel) :
								$id_alternatif2 = $alternatif2->id_alternatif2;
								$id_variabel = $variabel->id_variabel;
								echo '<td>';
								echo $matriks_x[$id_variabel][$id_alternatif2];
								echo '</td>';
							endforeach;
							?>
						</tr>
					<?php
						$no++;
					endforeach;
					?>
				</tbody>
			</table>
		</div>
	</div>
</div>

<?php
foreach ($variabels as $variabel) {
	$id_variabel = $variabel->id_variabel;
	$himpunans = $this->Perhitungan_model->get_himpunan($id_variabel);
?>
	<div class="card shadow mb-4">
		<!-- /.card-header -->
		<div class="card-header py-3">
			<h6 class="m-0 font-weight-bold text-primary"><i class="fa fa-table"></i> Derajat Keanggotaan Variabel <?= $variabel->nama_variabel ?></h6>
		</div>

		<div class="card-body">
			<div class="table-responsive">
				<table class="table table-bordered" width="100%" cellspacing="0">
					<thead class="bg-primary text-white">
						<tr align="center">
							<th width="5%" rowspan="2" class="align-middle">No</th>
							<th rowspan="2" class="align-middle">Nama alternatif</th>
							<th rowspan="2" class="align-middle" width="20%"><?= $variabel->nama_variabel ?></th>
							<th colspan="<?= count($himpunans) ?>">Derajat Keanggotaan</th>
						</tr>
						<tr align="center">
							<?php
							foreach ($himpunans as $himpunan) : ?>
								<th width="10%"><?= $himpunan->nama_himpunan ?></th>
							<?php endforeach; ?>
						</tr>
					</thead>
					<tbody>
						<?php
						$no = 1;
						foreach ($alternatif2s as $alternatif2) :
							$id_alternatif2 = $alternatif2->id_alternatif2;
						?>
							<tr align="center">
								<td><?= $no; ?></td>
								<td align="left"><?= $alternatif2->nama ?></td>
								<?php
								echo '<td>';
								echo $matriks_x[$id_variabel][$id_alternatif2];
								echo '</td>';
								foreach ($himpunans as $himpunan) :
									$id_himpunan_fuzzy = $himpunan->id_himpunan_fuzzy;
									echo '<td>';
									echo $nilai_da[$id_variabel][$id_alternatif2][$id_himpunan_fuzzy];
									echo '</td>';
								endforeach;
								?>
							</tr>
						<?php
							$no++;
						endforeach;
						?>
					</tbody>
				</table>
			</div>
		</div>
	</div>
<?php
}
?>

<div class="card shadow mb-4">
	<!-- /.card-header -->
	<div class="card-header py-3">
		<h6 class="m-0 font-weight-bold text-primary"><i class="fa fa-table"></i> Penerapan Kedalam aturan2</h6>
	</div>

	<div class="card-body">
		<div class="table-responsive">
			<table class="table table-bordered" width="100%" cellspacing="0">
				<thead class="bg-primary text-white">
					<tr align="center">
						<th width="5%" rowspan="2">No</th>
						<?php foreach ($variabels as $variabel) : ?>
							<th><?= $variabel->nama_variabel ?></th>
						<?php endforeach; ?>
						<th>Output</th>
						<?php foreach ($alternatif2s as $alternatif2) : ?>
							<th><?= $alternatif2->nama ?></th>
						<?php endforeach; ?>
					</tr>
				</thead>
				<tbody>
					<?php
					$no = 1;
					foreach ($aturan2s as $aturan2) : ?>
						<tr align="center">
							<td><?= $no; ?></td>
							<?php
							$rule = $this->Perhitungan_model->get_rule($aturan2->kode_aturan2);
							foreach ($rule as $r) :
								echo '<td>';
								echo $r->nama_himpunan;
								echo '</td>';
							endforeach;
							?>
							<td><?= $aturan2->output ?></td>
							<?php

							foreach ($alternatif2s as $alternatif2) {
								$id_alternatif2 = $alternatif2->id_alternatif2;
								echo '<td>';
								$nmin = [];
								foreach ($variabels as $variabel) {
									$id_variabel = $variabel->id_variabel;
									$himpunans = $this->Perhitungan_model->get_himpunan($id_variabel);

									foreach ($himpunans as $himpunan) {
										$id_himpunan_fuzzy = $himpunan->id_himpunan_fuzzy;

										$rule = $this->Perhitungan_model->get_rule($aturan2->kode_aturan2);

										foreach ($rule as $r) {
											if ($r->id_himpunan_fuzzy == $id_himpunan_fuzzy) {
												$nmin[] = $nilai_da[$id_variabel][$id_alternatif2][$id_himpunan_fuzzy];
											}
										}
									}
								}
								echo min($nmin);
								echo '</td>';
							}
							?>
						</tr>
					<?php
						$no++;
					endforeach;

					?>
				</tbody>
			</table>
		</div>
	</div>
</div>

<div class="card shadow mb-4">
	<!-- /.card-header -->
	<div class="card-header py-3">
		<h6 class="m-0 font-weight-bold text-primary"><i class="fa fa-table"></i> Penegasan (Defuzzifikasi)</h6>
	</div>

	<div class="card-body">
		<div class="table-responsive">
			<table class="table table-bordered" width="100%" cellspacing="0">
				<thead class="bg-primary text-white">
					<tr align="center">
						<th width="5%" class="align-middle">No</th>
						<th width="20%" class="align-middle">Nama alternatif</th>
						<th class="align-middle">Perhitungan Defuzzifikasi</th>
						<th width="20%" class="align-middle">Weight Average (WA)</th>
					</tr>
				</thead>
				<tbody>
					<?php
					$no = 1;
					$this->Perhitungan_model->hapus_hasil2();
					foreach ($alternatif2s as $alternatif2) :
						$id_alternatif2 = $alternatif2->id_alternatif2;
					?>
						<tr align="center">
							<td class="align-middle"><?= $no; ?></td>
							<td align="left" class="align-middle"><?= $alternatif2->nama ?></td>
							<td class="align-middle">
								<?php
								$total1 = 0;
								$total2 = 0;
								$x = 1;
								foreach ($aturan2s as $aturan2) {
									$nmin = [];
									foreach ($variabels as $variabel) {
										$id_variabel = $variabel->id_variabel;
										$himpunans = $this->Perhitungan_model->get_himpunan($id_variabel);

										foreach ($himpunans as $himpunan) {
											$id_himpunan_fuzzy = $himpunan->id_himpunan_fuzzy;

											$rule = $this->Perhitungan_model->get_rule($aturan2->kode_aturan2);

											foreach ($rule as $r) {
												if ($r->id_himpunan_fuzzy == $id_himpunan_fuzzy) {
													$nmin[] = $nilai_da[$id_variabel][$id_alternatif2][$id_himpunan_fuzzy];
												}
											}
										}
									}
									$ai = min($nmin);
									$zi = $aturan2->output;
									$aizi = $ai * $zi;
									$total1 += $aizi;
									$total2 += $ai;
									echo "<span class='span_and_" . $x . "'>+</span>(" . $ai . "*" . $zi . ")";
									$x++;
								}
								echo "<hr/>";
								$z = 1;
								foreach ($aturan2s as $aturan2) {
									$nmin = [];
									foreach ($variabels as $variabel) {
										$id_variabel = $variabel->id_variabel;
										$himpunans = $this->Perhitungan_model->get_himpunan($id_variabel);

										foreach ($himpunans as $himpunan) {
											$id_himpunan_fuzzy = $himpunan->id_himpunan_fuzzy;

											$rule = $this->Perhitungan_model->get_rule($aturan2->kode_aturan2);

											foreach ($rule as $r) {
												if ($r->id_himpunan_fuzzy == $id_himpunan_fuzzy) {
													$nmin[] = $nilai_da[$id_variabel][$id_alternatif2][$id_himpunan_fuzzy];
												}
											}
										}
									}
									echo "<span class='span_and_" . $z . "'>+</span>" . min($nmin);
									$z++;
								}
								?>
							</td>
							<td class="align-middle"><?= $wa = $total1 / $total2; ?></td>
						</tr>
					<?php
						$hasil2_akhir = [
							'id_alternatif2' => $id_alternatif2,
							'nilai' => $wa,
						];
						$this->Perhitungan_model->insert_hasil2($hasil2_akhir);
						$no++;
					endforeach;
					?>
				</tbody>
			</table>
		</div>
	</div>
</div>


<?php
$this->load->view('layouts/footer_admin');
?>