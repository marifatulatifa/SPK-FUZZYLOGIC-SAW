<?php

defined('BASEPATH') or exit('No direct script access allowed');

class Perhitungan_model extends CI_Model
{

    public function get_variabel()
    {
        $query = $this->db->get('variabel');
        return $query->result();
    }

    public function get_aturan2()
    {
        $query = $this->db->query("SELECT kode_aturan2, output FROM aturan2 GROUP BY kode_aturan2");
        return $query->result();
    }

    public function get_rule($kode_aturan2)
    {
        $query = $this->db->query("SELECT * FROM aturan2 JOIN himpunan_fuzzy ON aturan2.id_himpunan_fuzzy=himpunan_fuzzy.id_himpunan_fuzzy JOIN variabel ON aturan2.id_variabel=variabel.id_variabel WHERE aturan2.kode_aturan2='$kode_aturan2';");
        return $query->result();
    }

    public function get_alternatif2()
    {
        $query = $this->db->get('alternatif2');
        return $query->result();
    }

    public function get_himpunan($id_variabel)
    {
        $query = $this->db->query("SELECT * FROM himpunan_fuzzy WHERE id_variabel='$id_variabel';");
        return $query->result();
    }

    public function data_nilai($id_alternatif2, $id_variabel)
    {
        $query = $this->db->query("SELECT * FROM penilaian2 WHERE id_alternatif2='$id_alternatif2' AND id_variabel='$id_variabel';");
        return $query->row_array();
    }

    public function get_himpunan_row($id_variabel)
    {
        $query = $this->db->query("SELECT * FROM hasil2 WHERE id_variabel='$id_variabel';");
        return $query->row();
    }

    public function get_hasil2()
    {
        $query = $this->db->query("SELECT * FROM hasil2 JOIN alternatif2 ON hasil2.id_alternatif2=alternatif2.id_alternatif2 ORDER BY hasil2.nilai DESC;");
        return $query->result();
    }

    public function insert_hasil2($hasil2_akhir = [])
    {
        $result = $this->db->insert('hasil2', $hasil2_akhir);
        return $result;
    }

    public function hapus_hasil2()
    {
        $query = $this->db->query("TRUNCATE TABLE hasil2;");
        return $query;
    }
}
