<?php

defined('BASEPATH') or exit('No direct script access allowed');

class aturan2_model extends CI_Model
{

    public function tampil()
    {
        $query = $this->db->query("SELECT kode_aturan2, output FROM aturan2 GROUP BY kode_aturan2");
        return $query->result();
    }

    public function tambah_data($kode_aturan2, $id_variabel, $id_himpunan_fuzzy, $output)
    {
        $query = $this->db->simple_query("INSERT INTO aturan2 VALUES (DEFAULT,'$kode_aturan2','$id_variabel','$id_himpunan_fuzzy',$output);");
        return $query;
    }

    public function edit_data($kode_aturan2, $id_variabel, $id_himpunan_fuzzy, $output)
    {
        $query = $this->db->simple_query("UPDATE aturan2 SET id_himpunan_fuzzy='$id_himpunan_fuzzy', output='$output' WHERE kode_aturan2='$kode_aturan2' AND id_variabel='$id_variabel';");
        return $query;
    }

    public function get_aturan2_row($kode_aturan2, $id_variabel)
    {
        $query = $this->db->query("SELECT * FROM aturan2 WHERE kode_aturan2='$kode_aturan2' AND id_variabel='$id_variabel';");
        return $query->row();
    }

    public function get_aturan2_row_grp($kode_aturan2)
    {
        $query = $this->db->query("SELECT * FROM aturan2 WHERE kode_aturan2='$kode_aturan2' GROUP BY kode_aturan2");
        return $query->row();
    }

    public function cek_data_aturan2($kode_aturan2, $id_variabel)
    {
        $query = $this->db->query("SELECT * FROM aturan2 WHERE kode_aturan2='$kode_aturan2' AND id_variabel='$id_variabel';");
        return $query->row();
    }

    public function get_variabel()
    {
        $query = $this->db->get('variabel');
        return $query->result();
    }

    public function get_himpunan($id_variabel)
    {
        $query = $this->db->query("SELECT * FROM himpunan_fuzzy WHERE id_variabel='$id_variabel';");
        return $query->result();
    }

    public function get_rule($kode_aturan2)
    {
        $query = $this->db->query("SELECT * FROM aturan2 JOIN himpunan_fuzzy ON aturan2.id_himpunan_fuzzy=himpunan_fuzzy.id_himpunan_fuzzy JOIN variabel ON aturan2.id_variabel=variabel.id_variabel WHERE aturan2.kode_aturan2='$kode_aturan2';");
        return $query->result();
    }

    public function cek_kode()
    {
        $query = $this->db->query("SELECT MAX(kode_aturan2) as kode_aturan2 FROM aturan2");
        $hasil2 = $query->row();
        return $hasil2->kode_aturan2;
    }

    public function delete($kode_aturan2)
    {
        $this->db->where('kode_aturan2', $kode_aturan2);
        $this->db->delete('aturan2');
    }
}
