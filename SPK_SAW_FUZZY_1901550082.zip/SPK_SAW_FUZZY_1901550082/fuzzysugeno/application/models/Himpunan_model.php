<?php
    
    defined('BASEPATH') OR exit('No direct script access allowed');
    
    class Himpunan_model extends CI_Model {

        public function tampil()
        {
            $query = $this->db->get('himpunan_fuzzy');
            return $query->result();
        }

        public function insert($data = [])
        {
            $result = $this->db->insert('himpunan_fuzzy', $data);
            return $result;
        }

        public function show($id_himpunan_fuzzy)
        {
            $this->db->where('id_himpunan_fuzzy', $id_himpunan_fuzzy);
            $query = $this->db->get('himpunan_fuzzy');
            return $query->row();
        }

        public function update($id_himpunan_fuzzy, $data = [])
        {
            $ubah = array(
                'id_variabel' => $data['id_variabel'],
                'nama_himpunan' => $data['nama_himpunan'],
                'kurva'  => $data['kurva'],
				'a'  => $data['a'],
				'b'  => $data['b'],
				'c'  => $data['c'],
				'd'  => $data['d'],
            );

            $this->db->where('id_himpunan_fuzzy', $id_himpunan_fuzzy);
            $this->db->update('himpunan_fuzzy', $ubah);
        }

        public function delete($id_himpunan_fuzzy)
        {
            $this->db->where('id_himpunan_fuzzy', $id_himpunan_fuzzy);
            $this->db->delete('himpunan_fuzzy');
        }

        public function get_variabel()
        {
            $query = $this->db->get('variabel');
            return $query->result();
        }

        public function count_variabel(){
            $query =  $this->db->query("SELECT id_variabel FROM himpunan_fuzzy GROUP BY id_variabel")->result();
            return $query;
        }

        public function data_himpunan_fuzzy($id_variabel)
		{
			$query = $this->db->query("SELECT * FROM himpunan_fuzzy WHERE id_variabel='$id_variabel';");
			return $query->result_array();
		}
    }
    
    /* End of file Kategori_model.php */
    