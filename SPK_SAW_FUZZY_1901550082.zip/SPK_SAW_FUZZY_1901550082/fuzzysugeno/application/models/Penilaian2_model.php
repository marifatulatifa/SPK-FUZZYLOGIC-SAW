<?php

defined('BASEPATH') or exit('No direct script access allowed');

class penilaian2_model extends CI_Model
{

    public function tambah_penilaian2($id_alternatif2, $id_variabel, $nilai)
    {
        $query = $this->db->simple_query("INSERT INTO penilaian2 VALUES (DEFAULT,'$id_alternatif2','$id_variabel',$nilai);");
        return $query;
    }

    public function edit_penilaian2($id_alternatif2, $id_variabel, $nilai)
    {
        $query = $this->db->simple_query("UPDATE penilaian2 SET nilai=$nilai WHERE id_alternatif2='$id_alternatif2' AND id_variabel='$id_variabel';");
        return $query;
    }

    public function get_variabel()
    {
        $query = $this->db->get('variabel');
        return $query->result();
    }

    public function get_alternatif2()
    {
        $query = $this->db->query("SELECT * FROM alternatif2");
        return $query->result();
    }

    public function data_penilaian2($id_alternatif2, $id_variabel)
    {
        $query = $this->db->query("SELECT * FROM penilaian2 WHERE id_alternatif2='$id_alternatif2' AND id_variabel='$id_variabel';");
        return $query->row_array();
    }

    public function untuk_tombol($id_alternatif2)
    {
        $query = $this->db->query("SELECT * FROM penilaian2 WHERE id_alternatif2='$id_alternatif2';");
        return $query->num_rows();
    }
}
