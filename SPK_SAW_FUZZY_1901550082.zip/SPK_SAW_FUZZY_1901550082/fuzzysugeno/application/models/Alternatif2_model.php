<?php
    
    defined('BASEPATH') OR exit('No direct script access allowed');
    
    class alternatif2_model extends CI_Model {

        public function tampil()
        {
            $query = $this->db->get('alternatif2');
            return $query->result();
        }

        public function insert($data = [])
        {
            $result = $this->db->insert('alternatif2', $data);
            return $result;
        }

        public function show($id_alternatif2)
        {
            $this->db->where('id_alternatif2', $id_alternatif2);
            $query = $this->db->get('alternatif2');
            return $query->row();
        }

        public function update($id_alternatif2, $data = [])
        {
            $ubah = array(
                'nama'  => $data['nama']
            );

            $this->db->where('id_alternatif2', $id_alternatif2);
            $this->db->update('alternatif2', $ubah);
        }

        public function delete($id_alternatif2)
        {
            $this->db->where('id_alternatif2', $id_alternatif2);
            $this->db->delete('alternatif2');
        }
    }
    
    