<?php
    
    defined('BASEPATH') OR exit('No direct script access allowed');
    
    class Variabel_model extends CI_Model {

        public function tampil()
        {
            $query = $this->db->get('variabel');
            return $query->result();
        }

        public function insert($data = [])
        {
            $result = $this->db->insert('variabel', $data);
            return $result;
        }

        public function show($id_variabel)
        {
            $this->db->where('id_variabel', $id_variabel);
            $query = $this->db->get('variabel');
            return $query->row();
        }

        public function update($id_variabel, $data = [])
        {
            $ubah = array(
                'nama_variabel' => $data['nama_variabel'],
            );

            $this->db->where('id_variabel', $id_variabel);
            $this->db->update('variabel', $ubah);
        }

        public function delete($id_variabel)
        {
            $this->db->where('id_variabel', $id_variabel);
            $this->db->delete('variabel');
        }
    }
    