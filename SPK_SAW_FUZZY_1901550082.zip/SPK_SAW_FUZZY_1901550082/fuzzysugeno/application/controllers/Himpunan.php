<?php

defined('BASEPATH') or exit('No direct script access allowed');

class Himpunan extends CI_Controller
{

    public function __construct()
    {
        parent::__construct();
        $this->load->library('pagination');
        $this->load->library('form_validation');
        $this->load->model('Himpunan_model');
    }

    public function index()
    {
        $data = [
            'page' => "Himpunan",
            'list' => $this->Himpunan_model->tampil(),
            'variabel' => $this->Himpunan_model->get_variabel(),
            'count_variabel' => $this->Himpunan_model->count_variabel(),
            'himpunan' => $this->Himpunan_model->tampil()

        ];
        $this->load->view('himpunan/index', $data);
    }

    public function store()
    {
        $data = [
            'id_variabel' => $this->input->post('id_variabel'),
            'nama_himpunan' => $this->input->post('nama_himpunan'),
            'kurva' => $this->input->post('kurva'),
            'a' => $this->input->post('a'),
            'b' => $this->input->post('b'),
            'c' => $this->input->post('c'),
            'd' => $this->input->post('d'),
        ];

        $this->form_validation->set_rules('id_variabel', 'ID Kriteria', 'required');
        $this->form_validation->set_rules('nama_himpunan', 'Nama Himpunan', 'required');

        if ($this->form_validation->run() != false) {
            $result = $this->Himpunan_model->insert($data);
            if ($result) {
                $this->session->set_flashdata('message', '<div class="alert alert-success" role="alert">Data berhasil2 disimpan!</div>');
                redirect('Himpunan');
            }
        } else {
            $this->session->set_flashdata('message', '<div class="alert alert-primary" role="alert">Data gagal disimpan!</div>');
            redirect('Himpunan/create');
        }
    }

    public function update($id_himpunan_fuzzy)
    {
        $id_himpunan_fuzzy = $this->input->post('id_himpunan_fuzzy');
        $data = array(
            'id_variabel' => $this->input->post('id_variabel'),
            'nama_himpunan' => $this->input->post('nama_himpunan'),
            'kurva' => $this->input->post('kurva'),
            'a' => $this->input->post('a'),
            'b' => $this->input->post('b'),
            'c' => $this->input->post('c'),
            'd' => $this->input->post('d'),
        );

        $this->Himpunan_model->update($id_himpunan_fuzzy, $data);
        $this->session->set_flashdata('message', '<div class="alert alert-success" role="alert">Data berhasil2 diupdate!</div>');
        redirect('Himpunan');
    }

    public function destroy($id_himpunan_fuzzy)
    {
        $this->Himpunan_model->delete($id_himpunan_fuzzy);
        $this->session->set_flashdata('message', '<div class="alert alert-success" role="alert">Data berhasil2 dihapus!</div>');
        redirect('Himpunan');
    }
}
