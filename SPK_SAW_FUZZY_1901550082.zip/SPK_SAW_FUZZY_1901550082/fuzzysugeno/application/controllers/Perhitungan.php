<?php

defined('BASEPATH') or exit('No direct script access allowed');

class Perhitungan extends CI_Controller
{

    public function __construct()
    {
        parent::__construct();
        $this->load->library('pagination');
        $this->load->library('form_validation');
        $this->load->model('Perhitungan_model');
    }

    public function index()
    { {
?>
            
<?php
        }

        $data = [
            'page' => "Perhitungan",
            'aturan2s' => $this->Perhitungan_model->get_aturan2(),
            'variabels' => $this->Perhitungan_model->get_variabel(),
            'alternatif2s' => $this->Perhitungan_model->get_alternatif2(),
        ];

        $this->load->view('perhitungan/index', $data);
    }
}
