<?php

defined('BASEPATH') or exit('No direct script access allowed');

class Variabel extends CI_Controller
{

    public function __construct()
    {
        parent::__construct();
        $this->load->library('pagination');
        $this->load->library('form_validation');
        $this->load->model('Variabel_model');
    }

    public function index()
    {
        $data['page'] = "Variabel";
        $data['list'] = $this->Variabel_model->tampil();
        $this->load->view('variabel/index', $data);
    }

    //menampilkan view create
    public function create()
    {
        $data['page'] = "Variabel";
        $this->load->view('variabel/create', $data);
    }

    public function store()
    {
        $data = [
            'nama_variabel' => $this->input->post('nama_variabel'),
        ];

        $this->form_validation->set_rules('nama_variabel', 'Nama', 'required');

        if ($this->form_validation->run() != false) {
            $result = $this->Variabel_model->insert($data);
            if ($result) {
                $this->session->set_flashdata('message', '<div class="alert alert-success" role="alert">Data berhasil2 disimpan!</div>');
                redirect('Variabel');
            }
        } else {
            $this->session->set_flashdata('message', '<div class="alert alert-primary" role="alert">Data gagal disimpan!</div>');
            redirect('Variabel/create');
        }
    }

    public function edit($id_variabel)
    {
        $data['page'] = "Variabel";
        $data['variabel'] = $this->Variabel_model->show($id_variabel);
        $this->load->view('variabel/edit', $data);
    }

    public function update($id_variabel)
    {
        $id_variabel = $this->input->post('id_variabel');
        $data = array(
            'nama_variabel' => $this->input->post('nama_variabel'),
        );

        $this->Variabel_model->update($id_variabel, $data);
        $this->session->set_flashdata('message', '<div class="alert alert-success" role="alert">Data berhasil2 diupdate!</div>');
        redirect('Variabel');
    }

    public function destroy($id_variabel)
    {
        $this->Variabel_model->delete($id_variabel);
        $this->session->set_flashdata('message', '<div class="alert alert-success" role="alert">Data berhasil2 dihapus!</div>');
        redirect('Variabel');
    }
}
