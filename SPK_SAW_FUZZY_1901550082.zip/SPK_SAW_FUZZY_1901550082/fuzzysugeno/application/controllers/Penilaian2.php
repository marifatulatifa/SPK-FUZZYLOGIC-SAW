<?php

defined('BASEPATH') or exit('No direct script access allowed');

class penilaian2 extends CI_Controller
{

    public function __construct()
    {
        parent::__construct();
        $this->load->library('pagination');
        $this->load->library('form_validation');
        $this->load->model('penilaian2_model');
    }

    public function index()
    {
        $data = [
            'page' => "penilaian2",
            'variabel' => $this->penilaian2_model->get_variabel(),
            'alternatif2' => $this->penilaian2_model->get_alternatif2(),
        ];
        $this->load->view('penilaian2/index', $data);
    }


    public function tambah_penilaian2()
    {
        $id_alternatif2 = $this->input->post('id_alternatif2');
        $id_variabel = $this->input->post('id_variabel');
        $nilai = $this->input->post('nilai');
        $i = 0;
        echo var_dump($nilai);
        foreach ($nilai as $key) {
            $this->penilaian2_model->tambah_penilaian2($id_alternatif2, $id_variabel[$i], $key);
            $i++;
        }
        $this->session->set_flashdata('message', '<div class="alert alert-success" role="alert">Data berhasil2 disimpan!</div>');
        redirect('penilaian2');
    }

    public function update_penilaian2()
    {
        $id_alternatif2 = $this->input->post('id_alternatif2');
        $id_variabel = $this->input->post('id_variabel');
        $nilai = $this->input->post('nilai');
        $i = 0;

        foreach ($nilai as $key) {
            $cek = $this->penilaian2_model->data_penilaian2($id_alternatif2, $id_variabel[$i]);
            if ($cek == 0) {
                $this->penilaian2_model->tambah_penilaian2($id_alternatif2, $id_variabel[$i], $key);
            } else {
                $this->penilaian2_model->edit_penilaian2($id_alternatif2, $id_variabel[$i], $key);
            }
            $i++;
        }
        $this->session->set_flashdata('message', '<div class="alert alert-success" role="alert">Data berhasil2 diupdate!</div>');
        redirect('penilaian2');
    }
}
