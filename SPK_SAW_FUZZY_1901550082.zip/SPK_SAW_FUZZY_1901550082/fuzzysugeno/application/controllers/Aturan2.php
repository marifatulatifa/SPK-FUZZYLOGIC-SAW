<?php

defined('BASEPATH') or exit('No direct script access allowed');

class aturan2 extends CI_Controller
{

    public function __construct()
    {
        parent::__construct();
        $this->load->library('pagination');
        $this->load->library('form_validation');
        $this->load->model('aturan2_model');
    }

    public function index()
    {
        $data = [
            'page' => "aturan2",
            'list' => $this->aturan2_model->tampil(),
        ];
        $this->load->view('aturan2/index', $data);
    }

    //menampilkan view create
    public function create()
    {
        $data = [
            'page' => "aturan2",
            'variabel' => $this->aturan2_model->get_variabel(),
        ];
        $this->load->view('aturan2/create', $data);
    }

    //menambahkan data ke database
    public function store()
    {
        $dariDB = $this->aturan2_model->cek_kode();
        $nourut = substr($dariDB, 3, 4);
        $kode = $nourut + 1;
        $kode_aturan2 =  "R" . sprintf("%04s", $kode);
        $id_variabel = $this->input->post('id_variabel');
        $id_himpunan_fuzzy = $this->input->post('id_himpunan_fuzzy');
        $output = $this->input->post('output');
        $i = 0;
        echo var_dump($id_himpunan_fuzzy);
        foreach ($id_himpunan_fuzzy as $key) {
            $this->aturan2_model->tambah_data($kode_aturan2, $id_variabel[$i], $key, $output);
            $i++;
        }
        $this->session->set_flashdata('message', '<div class="alert alert-success" role="alert">Data berhasil2 disimpan!</div>');
        redirect('aturan2');
    }

    public function edit($kode_aturan2)
    {
        $data = [
            'page' => "aturan2",
            'variabel' => $this->aturan2_model->get_variabel(),
            'kode_aturan2' => $kode_aturan2,
            'aturan2_row' => $this->aturan2_model->get_aturan2_row_grp($kode_aturan2),
        ];
        $this->load->view('aturan2/edit', $data);
    }

    public function update()
    {
        $kode_aturan2 = $this->input->post('kode_aturan2');
        $id_variabel = $this->input->post('id_variabel');
        $id_himpunan_fuzzy = $this->input->post('id_himpunan_fuzzy');
        $output = $this->input->post('output');
        $i = 0;
        foreach ($id_himpunan_fuzzy as $key) {
            $cek = $this->aturan2_model->cek_data_aturan2($kode_aturan2, $id_variabel[$i]);
            if ($cek == 0) {
                $this->aturan2_model->tambah_data($kode_aturan2, $id_variabel[$i], $key, $output);
            } else {
                $this->aturan2_model->edit_data($kode_aturan2, $id_variabel[$i], $key, $output);
            }
            $i++;
        }
        $this->session->set_flashdata('message', '<div class="alert alert-success" role="alert">Data berhasil2 diupdate!</div>');
        redirect('aturan2');
    }

    public function destroy($id_aturan2)
    {
        $this->aturan2_model->delete($id_aturan2);
        $this->session->set_flashdata('message', '<div class="alert alert-success" role="alert">Data berhasil2 dihapus!</div>');
        redirect('aturan2');
    }
}
