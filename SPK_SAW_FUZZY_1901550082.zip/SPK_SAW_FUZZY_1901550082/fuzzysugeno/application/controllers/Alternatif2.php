<?php

defined('BASEPATH') or exit('No direct script access allowed');

class alternatif2 extends CI_Controller
{

    public function __construct()
    {
        parent::__construct();
        $this->load->library('pagination');
        $this->load->library('form_validation');
        $this->load->model('alternatif2_model');
    }

    public function index()
    {
        $data = [
            'page' => "alternatif2",
            'list' => $this->alternatif2_model->tampil(),
        ];
        $this->load->view('alternatif2/index', $data);
    }

    //menampilkan view create
    public function create()
    {
        $data['page'] = "alternatif2";
        $this->load->view('alternatif2/create', $data);
    }

    //menambahkan data ke database
    public function store()
    {
        $data = [
            'nama' => $this->input->post('nama')
        ];

        $this->form_validation->set_rules('nama', 'Nama', 'required');

        if ($this->form_validation->run() != false) {
            $result = $this->alternatif2_model->insert($data);
            if ($result) {
                $this->session->set_flashdata('message', '<div class="alert alert-success" role="alert">Data berhasil2 disimpan!</div>');
                redirect('alternatif2');
            }
        } else {
            $this->session->set_flashdata('message', '<div class="alert alert-primary" role="alert">Data gagal disimpan!</div>');
            redirect('alternatif2/create');
        }
    }

    public function edit($id_alternatif2)
    {
        $alternatif2 = $this->alternatif2_model->show($id_alternatif2);
        $data = [
            'page' => "alternatif2",
            'alternatif2' => $alternatif2
        ];
        $this->load->view('alternatif2/edit', $data);
    }

    public function update($id_alternatif2)
    {
        $id_alternatif2 = $this->input->post('id_alternatif2');
        $data = array(
            'nama' => $this->input->post('nama')
        );

        $this->alternatif2_model->update($id_alternatif2, $data);
        $this->session->set_flashdata('message', '<div class="alert alert-success" role="alert">Data berhasil2 diupdate!</div>');
        redirect('alternatif2');
    }

    public function destroy($id_alternatif2)
    {
        $this->alternatif2_model->delete($id_alternatif2);
        $this->session->set_flashdata('message', '<div class="alert alert-success" role="alert">Data berhasil2 dihapus!</div>');
        redirect('alternatif2');
    }
}
